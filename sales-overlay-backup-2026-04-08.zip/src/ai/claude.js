var Anthropic = require('@anthropic-ai/sdk');
var prompts = require('./prompts');
var objections = require('./objections');

// Common filler words that appear in almost any sentence — don't count these toward delivery
var STOP_WORDS = [
  'the', 'that', 'this', 'what', 'when', 'where', 'which', 'who', 'how',
  'you', 'your', 'they', 'them', 'their', 'she', 'her', 'him', 'his',
  'are', 'was', 'were', 'been', 'being', 'have', 'has', 'had', 'having',
  'does', 'did', 'doing', 'will', 'would', 'could', 'should', 'might',
  'can', 'may', 'shall', 'must', 'need',
  'for', 'and', 'but', 'not', 'with', 'from', 'about', 'into', 'just',
  'also', 'than', 'then', 'very', 'really', 'like', 'right', 'here',
  'there', 'now', 'out', 'get', 'got', 'let', 'make', 'made', 'know',
  'think', 'say', 'said', 'tell', 'told', 'going', 'come', 'came',
  'want', 'see', 'look', 'take', 'give', 'well', 'still', 'back',
  'even', 'way', 'own', 'same', 'any', 'some', 'all', 'most', 'more',
  'other', 'much', 'sure', 'okay', 'yeah', 'yes', 'mean', 'thing',
  'things', 'thats', "that's", 'its', "it's",
];

// Fuzzy match — checks if enough MEANINGFUL words from the suggestion appear in what the closer said
function hasDeliveredLine(spokenText, suggestedText) {
  if (!suggestedText) return true; // No active suggestion = free to advance

  // Normalize both strings
  var spoken = spokenText.toLowerCase().replace(/[^a-z0-9\s]/g, '');
  var suggested = suggestedText.toLowerCase().replace(/[^a-z0-9\s]/g, '');

  // Extract meaningful words (4+ chars, not stop words) from the suggestion
  var suggestedWords = suggested.split(/\s+/).filter(function(w) {
    return w.length >= 4 && STOP_WORDS.indexOf(w) === -1;
  });

  // If suggestion is mostly filler (less than 3 meaningful words), require at least 2
  if (suggestedWords.length < 3) return false;

  // Count how many suggested words appear in what was spoken
  var matchCount = 0;
  for (var i = 0; i < suggestedWords.length; i++) {
    if (spoken.indexOf(suggestedWords[i]) !== -1) {
      matchCount++;
    }
  }

  // Require 40%+ of meaningful words AND at least 3 matches
  var matchRatio = matchCount / suggestedWords.length;
  return matchRatio >= 0.40 && matchCount >= 3;
}

class ClaudeCoach {
  constructor(apiKey, knowledgeBase, callMemory) {
    this.client = new Anthropic({ apiKey: apiKey });
    this.kb = knowledgeBase || null;
    this.memory = callMemory || null;
    this.callBuffer = [];
    this.lastCallTime = 0;
    this.minInterval = 5000; // 5 seconds minimum between API calls
    this.turnsSinceLastCall = 0;
    this.minTurnsBetweenCalls = 2;

    // Delivery tracking
    this.currentSuggestion = null;   // The suggestion text currently displayed
    this.suggestionDelivered = true; // Start true so first call can fire
    this.closerSpeechSinceSuggestion = ''; // Accumulates closer speech since last suggestion
    this.suggestionTimestamp = 0;    // When the current suggestion was set
    this.turnsSinceSuggestion = 0;   // How many closer turns since current suggestion

    // Suggestion history — prevents Claude from repeating itself
    this.recentSuggestions = [];     // Last N suggestions sent to overlay
    this.maxSuggestionHistory = 5;   // Track last 5 suggestions

    // Delivery gate fallback — if closer hasn't delivered after this many turns or seconds, advance anyway
    this.maxTurnsBeforeAutoAdvance = 4;   // 4 closer turns = they moved on
    this.maxSecondsBeforeAutoAdvance = 30; // 30 seconds = they moved on
  }

  addTurn(text, speaker) {
    this.callBuffer.push({ text: text, speaker: speaker, timestamp: Date.now() });
    if (this.callBuffer.length > 16) {
      this.callBuffer = this.callBuffer.slice(-16);
    }
    this.turnsSinceLastCall++;

    // Track closer speech for delivery detection
    if (speaker === 'CLOSER' && this.currentSuggestion) {
      this.closerSpeechSinceSuggestion += ' ' + text;
      this.turnsSinceSuggestion++;

      if (!this.suggestionDelivered) {
        // Check 1: Did closer say enough of the suggestion words?
        if (hasDeliveredLine(this.closerSpeechSinceSuggestion, this.currentSuggestion)) {
          this.suggestionDelivered = true;
          console.log('[claude] Closer delivered the line — ready for next prompt (turn ' + this.turnsSinceSuggestion + ')');
        }
        // Check 2: Auto-advance after N closer turns (they moved on without saying it verbatim)
        else if (this.turnsSinceSuggestion >= this.maxTurnsBeforeAutoAdvance) {
          this.suggestionDelivered = true;
          console.log('[claude] Auto-advancing — closer spoke ' + this.turnsSinceSuggestion + ' turns without delivering (moved on)');
        }
        // Check 3: Auto-advance after N seconds (conversation kept going)
        else if (Date.now() - this.suggestionTimestamp > this.maxSecondsBeforeAutoAdvance * 1000) {
          this.suggestionDelivered = true;
          console.log('[claude] Auto-advancing — ' + this.maxSecondsBeforeAutoAdvance + 's elapsed since last suggestion');
        }
      }
    }

    // Also feed to call memory for long-term context
    if (this.memory) {
      this.memory.addTurn(text, speaker);
    }
  }

  getTranscriptString() {
    return this.callBuffer.map(function(turn) {
      return turn.speaker + ': ' + turn.text;
    }).join('\n');
  }

  async getSuggestion(onSuggestion) {
    var now = Date.now();

    // Rate limiting: time-based AND turn-based
    if (now - this.lastCallTime < this.minInterval) return;
    if (this.callBuffer.length < 2) return;

    var lastTurn = this.callBuffer[this.callBuffer.length - 1];
    var transcript = this.getTranscriptString();

    // 1. Check hardcoded objections FIRST — BEFORE the delivery gate
    //    Objections bypass everything (they're urgent and time-sensitive)
    if (lastTurn.speaker === 'PROSPECT') {
      var localMatch = objections.detectObjection(lastTurn.text);
      if (localMatch) {
        console.log('[claude] Local objection match: ' + localMatch.label);
        var objSuggestion = {
          stage: 'objection_handling',
          headline: localMatch.label + ' — Phase 1',
          suggestion: localMatch.rebuttal,
          followUp: localMatch.followUp,
          urgency: 'high',
          source: 'local',
        };

        // Track this as the new current suggestion
        this.currentSuggestion = localMatch.rebuttal;
        this.suggestionDelivered = false;
        this.closerSpeechSinceSuggestion = '';
        this.suggestionTimestamp = Date.now();
        this.turnsSinceSuggestion = 0;

        onSuggestion(objSuggestion);
        this.lastCallTime = now;
        this.turnsSinceLastCall = 0;
        return;
      }
    }

    // DELIVERY GATE + TURN GATE: Only applies to Claude API suggestions (not objections)
    if (this.turnsSinceLastCall < this.minTurnsBetweenCalls) return;
    if (!this.suggestionDelivered) {
      if (this.suggestionTimestamp && Date.now() - this.suggestionTimestamp > this.maxSecondsBeforeAutoAdvance * 1000) {
        this.suggestionDelivered = true;
        console.log('[claude] Auto-advancing in getSuggestion — timeout reached');
      } else {
        return;
      }
    }

    this.lastCallTime = now;
    this.turnsSinceLastCall = 0;

    try {
      // 2. Search knowledge base for relevant context
      var kbContext = '';
      if (this.kb) {
        console.log('[claude] Searching knowledge base...');
        var kbResults = await this.kb.searchByText(lastTurn.text, 3);
        if (kbResults && kbResults.length > 0) {
          kbContext = this.kb.buildContext(kbResults);
          console.log('[claude] Found ' + kbResults.length + ' KB matches');
        }
      }

      // 3. Get call memory context
      var memoryContext = '';
      if (this.memory) {
        memoryContext = this.memory.getContext();
        if (memoryContext) {
          console.log('[claude] Call stage: ' + this.memory.detectedStage + ' | Turns: ' + this.memory.getTurnCount());
        }
      }

      // 4. Build suggestion history context (anti-repetition)
      var suggestionHistory = '';
      if (this.recentSuggestions.length > 0) {
        var historyLines = this.recentSuggestions.map(function(s) {
          return '- ' + s.headline + ': "' + s.suggestion + '"';
        });
        suggestionHistory = 'ALREADY SUGGESTED (DO NOT REPEAT THESE — move the conversation FORWARD):\n' + historyLines.join('\n');
      }

      // 5. Call Claude with full context
      console.log('[claude] Calling Claude API...');
      var userPrompt = prompts.buildSuggestionPrompt(transcript, null, kbContext, memoryContext, suggestionHistory);

      var response = await this.client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        system: prompts.SYSTEM_PROMPT,
        messages: [{ role: 'user', content: userPrompt }],
      });

      var content = response.content[0] ? response.content[0].text : null;
      if (!content) return;

      // Strip markdown code fences if Claude wraps the JSON
      var jsonStr = content.trim();
      if (jsonStr.indexOf('```') === 0) {
        jsonStr = jsonStr.replace(/^```(?:json)?\s*/, '').replace(/```\s*$/, '').trim();
      }

      var parsed = JSON.parse(jsonStr);
      // Always send the suggestion — this is a live teleprompter, not a selective coach
      if (parsed.suggestion) {
        console.log('[claude] Next line: ' + parsed.headline);

        var newSuggestion = {
          stage: parsed.stage || (this.memory ? this.memory.detectedStage : 'discovery'),
          headline: parsed.headline || '',
          suggestion: parsed.suggestion,
          followUp: parsed.followUp || '',
          urgency: parsed.urgency || 'medium',
          source: kbContext ? 'kb+claude' : 'claude',
        };

        // Track this as the new current suggestion
        this.currentSuggestion = parsed.suggestion;
        this.suggestionDelivered = false;
        this.closerSpeechSinceSuggestion = '';
        this.suggestionTimestamp = Date.now();
        this.turnsSinceSuggestion = 0;

        // Add to suggestion history (for anti-repetition)
        this.recentSuggestions.push({
          headline: parsed.headline || '',
          suggestion: parsed.suggestion,
        });
        if (this.recentSuggestions.length > this.maxSuggestionHistory) {
          this.recentSuggestions = this.recentSuggestions.slice(-this.maxSuggestionHistory);
        }

        onSuggestion(newSuggestion);
      }
    } catch (err) {
      console.error('[claude] Error:', err.message);
    }
  }

  reset() {
    this.callBuffer = [];
    this.lastCallTime = 0;
    this.turnsSinceLastCall = 0;
    this.currentSuggestion = null;
    this.suggestionDelivered = true;
    this.closerSpeechSinceSuggestion = '';
    this.suggestionTimestamp = 0;
    this.turnsSinceSuggestion = 0;
    this.recentSuggestions = [];
    if (this.memory) {
      this.memory.reset();
    }
  }
}

module.exports = ClaudeCoach;
