# Memory

## Me
Justin Schmidt, justinschmidt@netrevenue.io. Building "Sales Overlay" as a personal side project (NOT for Net Revenue LLC). Not a developer — relies entirely on Claude for all code.

## Project: Sales Overlay
Real-time AI sales coaching teleprompter for high-ticket closers. Electron desktop app. Listens to live sales calls, transcribes in real time, displays a transparent overlay bar at top of screen showing the closer what to say next.

**Target vertical:** High-ticket coaching/consulting closers.
**Important:** No Net Revenue client content (SSI, GlobalBanks) — only universal sales framework structure.

## Tech Stack
| Tech | Purpose |
|------|---------|
| **Electron 41** | Desktop app, two windows (control panel + overlay) |
| **Deepgram Nova-2** | Real-time STT via raw WebSocket (SDK v5 broken, using raw WS) |
| **Anthropic Claude Sonnet** | Live teleprompter AI — always tells closer what to say next |
| **Supabase + pgvector** | Knowledge base / RAG for sales frameworks |
| **electron-audio-loopback** | Native system audio capture — no drivers needed, user just grants Screen Recording permission |

## Key Files
| File | What |
|------|------|
| `src/main/index.js` | Main Electron process, IPC, session lifecycle |
| `src/renderer/overlay/overlay.html` | Overlay bar — stacking prompt display |
| `src/renderer/control/index.html` | Control panel UI with audio device selectors |
| `src/renderer/control/control.js` | Audio capture, device enumeration, session controls |
| `src/ai/claude.js` | ClaudeCoach — rate limiting, delivery detection, objection bypass |
| `src/ai/prompts.js` | System prompt (live teleprompter mode), suggestion prompt builder |
| `src/ai/objections.js` | 4 framework + 6 secondary objections, prospect-only detection |
| `src/ai/call-memory.js` | Rolling summary every 8 turns, 7-stage detection |
| `src/ai/knowledge-base.js` | Supabase search, client filtering, framework phase lookup |
| `src/ai/script-parser.js` | Claude API parses uploaded .txt scripts into KB entries |
| `src/preload.js` | contextBridge IPC (includes logToMain for debug) |
| `scripts/seed-frameworks.js` | 65+ KB entries for sales frameworks |
| `scripts/clear-and-reseed.js` | Wipes and reseeds Supabase KB |

## Sales Frameworks in KB
- **Identity Shifting** objection methodology (Isolate > Binary Identity > Historical Pattern > Mirror Reality > Identity Choice)
- **SPAIN** discovery (Situation > Pain > Accountability > Implications > Needs Payoff)
- **V-L-F-A-R** dialogue (Validate > Label > Frame > Ask > Repeat)
- 4 main objection frameworks: Money (8 phases), Spouse (8), Think About It (10), No Time (6)
- 7 call stages: Introduction, Set, Discovery, Transition, Pitch, Close, Objection Handling

## Current Architecture Decisions
- **Overlay is click-through** (`setIgnoreMouseEvents(true, {forward: true})`) with a small drag handle top-left
- **Delivery-based prompts** — overlay only advances when closer says ~30% of key words from current suggestion (fuzzy match in claude.js)
- **Stacking prompts** — new prompts appear below, old ones fade to 30% opacity, max 3 visible
- **Objections bypass delivery gate** — they're urgent, show immediately
- **System audio loopback** — prospect audio captured natively via electron-audio-loopback (no BlackHole/virtual drivers needed). Single mic dropdown for closer.
- **Rate limiting** — 5s min interval + 2 turn minimum between Claude API calls
- **Renderer logs piped to terminal** via `logToMain` IPC + `renderer-log` handler

## Current Status: What Works
- Deepgram real-time transcription (closer's voice via mic)
- Claude API generating next-line suggestions as live teleprompter
- Overlay bar with stacking prompts and delivery detection
- 7-stage call detection (introduction through objection handling)
- Knowledge base search with framework phases
- Objection detection (prospect speech only, tightened triggers)
- Script upload + parse infrastructure (untested by user)
- Call memory with rolling summaries
- Click-through overlay with drag handle
- Audio device enumeration and dual-input UI

## Current Status: What's Broken / In Progress
1. **PROSPECT AUDIO** — Replaced BlackHole/virtual-driver approach with electron-audio-loopback (native system audio capture). User just needs to grant Screen Recording permission on first launch. Deepgram multichannel (channels=2) separates closer (ch0) and prospect (ch1). NEEDS TESTING with new loopback approach.
2. **KB not seeded** — User hasn't run `node scripts/clear-and-reseed.js` then `node scripts/seed-frameworks.js`. Old KB entries may be stale.

## Resolved Issues (for context)
- Overlay used to replace prompts mid-read → fixed with delivery detection + stacking
- False objection triggers on closer's speech → fixed with prospect-only guard
- Call memory JSON parse failures from markdown code fences → fixed with fence stripping
- Too many API calls → fixed with interval + turn gating
- Overlay was bottom-right popup → rebuilt as full-width top bar
- AI was selective coach → rewritten as always-on teleprompter
- desktopCapturer can't capture system audio on macOS → replaced with manual audio device selector + BlackHole → replaced with electron-audio-loopback (zero user setup)

## Brand
- **Name:** Scout Systems
- **Domain:** scoutsystems.io
- **Product name TBD** — "Sales Overlay" is the working title, may rename for launch

## Future Plans
- Onboarding wizard (offer, price, target prospect, top objections)
- Post-call summary (objections hit, suggestions used, missed opportunities)
- Railway backend (server-side API proxy, auth, user accounts)
- electron-builder packaging (.dmg/.exe)
- Website at scoutsystems.io
- See BUILD-PLAN.md for full 4-phase roadmap

## Preferences
- Justin is not a developer — explain things simply, provide exact terminal commands
- Always use universal sales framework structure, never client-specific content
- Test with `cd ~/sales-overlay && npm start`
